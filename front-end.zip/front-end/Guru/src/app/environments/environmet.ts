export const environment = {
    production: false,
    baseUrl: 'http://localhost:8090/guru'
}