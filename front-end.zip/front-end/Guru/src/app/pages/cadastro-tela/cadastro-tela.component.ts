import { Component } from '@angular/core';

@Component({
  selector: 'app-cadastro-tela',
  templateUrl: './cadastro-tela.component.html',
  styleUrls: ['./cadastro-tela.component.css']
})
export class CadastroTelaComponent {

}
