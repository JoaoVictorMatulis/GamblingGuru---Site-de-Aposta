import { Component } from '@angular/core';

@Component({
  selector: 'app-tabela-leaderboard',
  templateUrl: './tabela-leaderboard.component.html',
  styleUrls: ['./tabela-leaderboard.component.css']
})
export class TabelaLeaderboardComponent {

}
