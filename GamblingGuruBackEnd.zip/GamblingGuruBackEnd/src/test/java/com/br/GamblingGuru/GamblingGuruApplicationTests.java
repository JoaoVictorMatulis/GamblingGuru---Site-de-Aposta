package com.br.GamblingGuru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamblingGuruApplicationTests {

	@Test
	void contextLoads() {
	}

}
