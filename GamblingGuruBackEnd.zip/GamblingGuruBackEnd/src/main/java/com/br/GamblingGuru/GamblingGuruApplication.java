package com.br.GamblingGuru;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamblingGuruApplication implements CommandLineRunner{
	public static void main(String[] args) {
		SpringApplication.run(GamblingGuruApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
	}

}
